export default function Unauthorized() {
  return (
    <div style={{ padding: 24 }}>
      <h1>Unauthorized</h1>
      <p>You don’t have permission to view this page.</p>
    </div>
  );
}
